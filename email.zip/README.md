# Gen128
This is the official website for Gen128- A Software Company that specializes in Software Developement, Product Design, Project Management etc.
Started the developemnt of the website with the mobile view up to larger screens
